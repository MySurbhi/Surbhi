
import React from 'react';

interface FooterProps {
  firmName: string;
}

const Footer: React.FC<FooterProps> = ({ firmName }) => {
  return (
    <footer className="bg-slate-900/80 backdrop-blur-md text-center p-4 border-t border-slate-700 mt-auto">
      <p className="text-sm text-slate-400">
        &copy; {new Date().getFullYear()} {firmName}. All Rights Reserved.
      </p>
      <p className="text-xs text-red-400 font-semibold mt-1">CONFIDENTIAL</p>
    </footer>
  );
};

export default Footer;
