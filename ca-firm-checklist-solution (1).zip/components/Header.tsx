
import React from 'react';

interface HeaderProps {
  firmName: string;
}

const Header: React.FC<HeaderProps> = ({ firmName }) => {
  return (
    <header className="bg-slate-900/80 backdrop-blur-md shadow-lg p-4 border-b border-slate-700">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center space-x-2">
           <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 text-sky-500">
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z" />
          </svg>
          <h1 className="text-xl font-semibold text-sky-400">{firmName}</h1>
        </div>
        <div className="text-sm text-slate-400">Compliance Checklists</div>
      </div>
    </header>
  );
};

export default Header;
