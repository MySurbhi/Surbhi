
import React, { useRef, useState } from 'react';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { ChecklistData, ChecklistItem as ChecklistItemType } from '../types';
import { FIRM_NAME } from '../constants';

interface ChecklistDisplayProps {
  checklistData: ChecklistData | null | undefined;
  companyTypeSelected: boolean;
  serviceTypeSelected: boolean;
  noServicesDefined: boolean;
  selectedCompanyTypeLabel: string;
  selectedServiceTypeLabel: string;
}

const ChecklistItem: React.FC<{ item: ChecklistItemType, index: number }> = ({ item, index }) => {
  return (
    <li className="py-3 px-4 bg-slate-700/50 rounded-lg shadow flex items-start space-x-3 transition-all duration-300 hover:bg-slate-700">
      <span className="flex-shrink-0 w-6 h-6 bg-sky-500 text-slate-900 rounded-full flex items-center justify-center text-xs font-bold">
        {index + 1}
      </span>
      <div className="flex-grow">
        <p className="text-slate-200">{item.text}</p>
        {item.subItems && item.subItems.length > 0 && (
          <ul className="mt-2 pl-4 list-disc list-inside space-y-1 text-slate-400">
            {item.subItems.map((subItem, subIndex) => (
              <li key={`${item.id}-sub-${subIndex}`}>{subItem}</li>
            ))}
          </ul>
        )}
      </div>
    </li>
  );
};

const ChecklistDisplay: React.FC<ChecklistDisplayProps> = ({ 
    checklistData, 
    companyTypeSelected, 
    serviceTypeSelected, 
    noServicesDefined,
    selectedCompanyTypeLabel,
    selectedServiceTypeLabel 
}) => {
  const checklistContentRef = useRef<HTMLDivElement>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [copyButtonText, setCopyButtonText] = useState('Copy Text');

  const handleDownloadPDF = async () => {
    if (!checklistContentRef.current || !checklistData || !selectedCompanyTypeLabel || !selectedServiceTypeLabel) {
      console.error("Checklist content, company type, or service type not found for PDF generation.");
      return;
    }

    setIsGeneratingPdf(true);

    try {
      const canvas = await html2canvas(checklistContentRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#1e293b', 
      });
      const imgData = canvas.toDataURL('image/jpeg', 0.75); 

      const pdf = new jsPDF({
        orientation: 'p',
        unit: 'mm',
        format: 'a4',
      });

      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const margin = 15; 

      pdf.setFontSize(16);
      pdf.setTextColor(66, 150, 255); 
      pdf.text(FIRM_NAME, margin, margin);

      pdf.setFontSize(12);
      pdf.setTextColor(203, 213, 225); 
      const title = `Checklist for: ${selectedServiceTypeLabel}`;
      const subtitle = `(${selectedCompanyTypeLabel})`;
      pdf.text(title, margin, margin + 10);
      pdf.text(subtitle, margin, margin + 16);

      pdf.setDrawColor(71, 85, 105); 
      pdf.line(margin, margin + 20, pdfWidth - margin, margin + 20);
      
      let contentStartY = margin + 25;

      const imgProps = pdf.getImageProperties(imgData);
      let imgReportedWidth = imgProps.width;
      let imgReportedHeight = imgProps.height;

      let renderImgWidth = pdfWidth - 2 * margin;
      let renderImgHeight = (imgReportedHeight * renderImgWidth) / imgReportedWidth;
      
      const availableHeightForImage = pdfHeight - contentStartY - (margin + 15); // +15 for footer safety

      if (renderImgHeight > availableHeightForImage) {
        renderImgHeight = availableHeightForImage;
        renderImgWidth = (imgReportedWidth * renderImgHeight) / imgReportedHeight;
      }
      
      const imgX = (pdfWidth - renderImgWidth) / 2;

      pdf.addImage(imgData, 'JPEG', imgX, contentStartY, renderImgWidth, renderImgHeight);

      const footerY = pdfHeight - margin;
      pdf.setFontSize(10);
      pdf.setTextColor(220, 38, 38); 
      pdf.text("CONFIDENTIAL", pdfWidth / 2, footerY - 5, { align: 'center' });

      pdf.setFontSize(8);
      pdf.setTextColor(148, 163, 184); 
      const copyrightText = `© ${new Date().getFullYear()} ${FIRM_NAME}. All Rights Reserved.`;
      pdf.text(copyrightText, pdfWidth / 2, footerY, { align: 'center' });
      
      const companyTypeClean = selectedCompanyTypeLabel.replace(/\s+/g, '_').replace(/[^a-zA-Z0-9_]/g, '');
      const serviceTypeClean = selectedServiceTypeLabel.replace(/\s+/g, '_').replace(/[^a-zA-Z0-9_]/g, '');
      pdf.save(`Checklist_${companyTypeClean}_${serviceTypeClean}.pdf`);

    } catch (error) {
      console.error("Error generating PDF:", error);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handleCopyText = async () => {
    if (!checklistData || !selectedCompanyTypeLabel || !selectedServiceTypeLabel) {
      console.error("Checklist data, company type, or service type not found for copying.");
      return;
    }

    let textToCopy = '';
    const title = `Checklist for: ${selectedServiceTypeLabel} (${selectedCompanyTypeLabel})\n`;
    
    if (checklistData.type === 'list') {
      const listTitle = `Required Documents & Information:\n\n`;
      textToCopy = title + listTitle;
      textToCopy += checklistData.items.map((item, index) => {
        let itemText = `${index + 1}. ${item.text}`;
        if (item.subItems && item.subItems.length > 0) {
          itemText += '\n' + item.subItems.map(subItem => `    - ${subItem}`).join('\n');
        }
        return itemText;
      }).join('\n\n');
    } else if (checklistData.type === 'image') {
      const imageTitle = `Checklist Requirements:\n\n`;
      textToCopy = title + imageTitle + checklistData.alt;
       if (checklistData.src.includes('picsum.photos')) {
        textToCopy += "\n\n(Note: This is a placeholder image. Replace with the actual Form DPT-3 requirements image.)";
      }
    }

    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopyButtonText('Copied!');
      setTimeout(() => setCopyButtonText('Copy Text'), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
      setCopyButtonText('Copy Failed');
      setTimeout(() => setCopyButtonText('Copy Text'), 2000);
    }
  };


  if (!companyTypeSelected) {
    return (
      <div className="mt-8 p-6 bg-slate-700/50 rounded-lg text-center text-slate-400">
        <p>Please select a Company/LLP type to begin.</p>
      </div>
    );
  }

  if (noServicesDefined) {
     return (
      <div className="mt-8 p-6 bg-slate-700/50 rounded-lg text-center text-slate-400">
        <p>No services defined for the selected company type.</p>
      </div>
    );
  }

  if (!serviceTypeSelected) {
    return (
      <div className="mt-8 p-6 bg-slate-700/50 rounded-lg text-center text-slate-400">
        <p>Please select a service to view the checklist.</p>
      </div>
    );
  }
  
  if (checklistData === undefined) {
    return (
      <div className="mt-8 p-6 bg-red-900/30 border border-red-700 rounded-lg text-center text-red-300">
        <p className="font-semibold">Checklist Not Available</p>
        <p className="text-sm">The checklist for the selected service is not yet defined.</p>
      </div>
    );
  }

  if (!checklistData) { 
     return (
      <div className="mt-8 p-6 bg-slate-700/50 rounded-lg text-center text-slate-400">
        <p>Checklist will appear here once a service is selected.</p>
      </div>
    );
  }

  const renderActionButtons = () => (
    <div className="mt-6 text-center flex flex-row justify-center items-center space-x-3">
      <button
        onClick={handleCopyText}
        disabled={isGeneratingPdf || !selectedCompanyTypeLabel || !selectedServiceTypeLabel}
        className="bg-teal-500 hover:bg-teal-600 text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:shadow-lg transition-all duration-150 ease-in-out inline-flex items-center space-x-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 focus:ring-opacity-75 disabled:opacity-50 disabled:cursor-not-allowed"
        aria-label="Copy checklist text"
      >
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
          <path strokeLinecap="round" strokeLinejoin="round" d="M15.666 3.888A2.25 2.25 0 0 0 13.5 2.25h-3c-1.03 0-1.9.693-2.166 1.638m7.332 0c.055.194.084.4.084.612v0a8.967 8.967 0 0 1-2.083 6.15M9 12.75h3m3.375-3.375A2.25 2.25 0 0 0 13.5 7.5h-3a2.25 2.25 0 0 0-2.25 2.25v6.75A2.25 2.25 0 0 0 9 18.75h3.75A2.25 2.25 0 0 0 15 16.5V13.5a2.25 2.25 0 0 0-2.25-2.25H9" />
        </svg>
        <span>{copyButtonText}</span>
      </button>
      <button
        onClick={handleDownloadPDF}
        disabled={isGeneratingPdf || !selectedCompanyTypeLabel || !selectedServiceTypeLabel}
        className="bg-sky-500 hover:bg-sky-600 text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:shadow-lg transition-all duration-150 ease-in-out inline-flex items-center space-x-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-400 focus:ring-opacity-75 disabled:opacity-50 disabled:cursor-not-allowed"
        aria-label="Download checklist as PDF"
      >
        {isGeneratingPdf ? (
          <>
            <svg className="animate-spin -ml-1 mr-1.5 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <span>Generating...</span>
          </>
        ) : (
          <>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" />
            </svg>
            <span>Download PDF</span>
          </>
        )}
      </button>
    </div>
  );

  if (checklistData.type === 'image') {
    return (
      <div className="mt-8">
        <div ref={checklistContentRef} className="p-4 bg-slate-800 rounded-lg shadow-lg">
          <h3 className="text-xl font-semibold text-sky-400 mb-4">Checklist Requirements:</h3>
          <div className="flex justify-center items-center">
            <img 
              src={checklistData.src} 
              alt={checklistData.alt} 
              className="max-w-full h-auto rounded-md border-2 border-slate-600 shadow-md"
            />
          </div>
          {checklistData.src.includes('picsum.photos') && (
              <p className="text-center text-amber-400 mt-2 text-sm">Note: This is a placeholder image. Replace with the actual Form DPT-3 requirements image.</p>
          )}
        </div>
        {renderActionButtons()}
      </div>
    );
  }

  if (checklistData.type === 'list') {
    return (
      <div className="mt-8">
        <div ref={checklistContentRef} className="p-4 bg-slate-800 rounded-lg">
            <h3 className="text-2xl font-semibold text-sky-400 mb-6 border-b-2 border-sky-600 pb-2">Required Documents & Information:</h3>
            {checklistData.items.length > 0 ? (
            <ul className="space-y-3">
                {checklistData.items.map((item, index) => (
                <ChecklistItem key={item.id} item={item} index={index} />
                ))}
            </ul>
            ) : (
            <p className="text-slate-400 text-center py-4">No items in this checklist.</p>
            )}
        </div>
        {checklistData.items.length > 0 && renderActionButtons()}
      </div>
    );
  }

  return null; 
};

export default ChecklistDisplay;
